(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-header></app-header>\r\n<!-- 主体内容区域 -->\r\n<div class=\"main-container\">\r\n  <router-outlet></router-outlet>\r\n</div>\r\n<app-footer></app-footer>\r\n"

/***/ }),

/***/ "./src/app/app.component.less":
/*!************************************!*\
  !*** ./src/app/app.component.less ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "* {\n  margin: 0;\n}\n.main-container {\n  padding: 40px;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvRTovd3AvY29kZS9CaW9sb2d5L3NyYy9hcHAvYXBwLmNvbXBvbmVudC5sZXNzIiwic3JjL2FwcC9hcHAuY29tcG9uZW50Lmxlc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxVQUFBO0NDQ0Q7QURJRDtFQUNFLGNBQUE7Q0NGRCIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQubGVzcyIsInNvdXJjZXNDb250ZW50IjpbIioge1xuICBtYXJnaW46IDA7XG59XG5cblxuXG4ubWFpbi1jb250YWluZXIge1xuICBwYWRkaW5nOiA0MHB4O1xufVxuXG5cbiIsIioge1xuICBtYXJnaW46IDA7XG59XG4ubWFpbi1jb250YWluZXIge1xuICBwYWRkaW5nOiA0MHB4O1xufVxuIl19 */"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var AppComponent = /** @class */ (function () {
    function AppComponent() {
        this.title = 'Biology';
    }
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.less */ "./src/app/app.component.less")]
        })
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _app_routes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app.routes */ "./src/app/app.routes.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _home_home_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./home/home.component */ "./src/app/home/home.component.ts");
/* harmony import */ var _footer_footer_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./footer/footer.component */ "./src/app/footer/footer.component.ts");
/* harmony import */ var _header_header_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./header/header.component */ "./src/app/header/header.component.ts");
/* harmony import */ var _common_dropdown_direactive__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./common/dropdown.direactive */ "./src/app/common/dropdown.direactive.ts");
/* harmony import */ var _common_product_profile_productProfile_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./common/product-profile/productProfile.component */ "./src/app/common/product-profile/productProfile.component.ts");
/* harmony import */ var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ng-zorro-antd */ "./node_modules/ng-zorro-antd/fesm5/ng-zorro-antd.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_common_locales_zh__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common/locales/zh */ "./node_modules/@angular/common/locales/zh.js");
/* harmony import */ var _angular_common_locales_zh__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_angular_common_locales_zh__WEBPACK_IMPORTED_MODULE_11__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};












Object(_angular_common__WEBPACK_IMPORTED_MODULE_10__["registerLocaleData"])(_angular_common_locales_zh__WEBPACK_IMPORTED_MODULE_11___default.a);
var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"],
                _home_home_component__WEBPACK_IMPORTED_MODULE_4__["HomeComponent"],
                _footer_footer_component__WEBPACK_IMPORTED_MODULE_5__["FooterComponent"],
                _header_header_component__WEBPACK_IMPORTED_MODULE_6__["HeaderComponent"],
                _common_dropdown_direactive__WEBPACK_IMPORTED_MODULE_7__["MenuDropDownDirective"],
                _common_product_profile_productProfile_component__WEBPACK_IMPORTED_MODULE_8__["ProductProfileComponent"]
            ],
            imports: [
                _app_routes__WEBPACK_IMPORTED_MODULE_2__["routing"],
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
                ng_zorro_antd__WEBPACK_IMPORTED_MODULE_9__["NgZorroAntdModule"]
            ],
            providers: [{ provide: ng_zorro_antd__WEBPACK_IMPORTED_MODULE_9__["NZ_I18N"], useValue: ng_zorro_antd__WEBPACK_IMPORTED_MODULE_9__["zh_CN"] }],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/app.routes.ts":
/*!*******************************!*\
  !*** ./src/app/app.routes.ts ***!
  \*******************************/
/*! exports provided: appRoutes, routing */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "appRoutes", function() { return appRoutes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routing", function() { return routing; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _home_home_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home/home.component */ "./src/app/home/home.component.ts");


var appRoutes = [
    {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full'
    },
    {
        path: 'home',
        component: _home_home_component__WEBPACK_IMPORTED_MODULE_1__["HomeComponent"]
    }
];
var routing = _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forRoot(appRoutes);


/***/ }),

/***/ "./src/app/common/dropdown.direactive.ts":
/*!***********************************************!*\
  !*** ./src/app/common/dropdown.direactive.ts ***!
  \***********************************************/
/*! exports provided: MenuDropDownDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MenuDropDownDirective", function() { return MenuDropDownDirective; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var MenuDropDownDirective = /** @class */ (function () {
    function MenuDropDownDirective(elementRef, renderer) {
        this.elementRef = elementRef;
        this.renderer = renderer;
        this.el = this.elementRef.nativeElement;
    }
    MenuDropDownDirective.prototype.onMouseEnter = function () {
        this.renderer.addClass(this.elementRef.nativeElement, 'open');
    };
    MenuDropDownDirective.prototype.onMouseLeave = function () {
        this.renderer.removeClass(this.elementRef.nativeElement, 'open');
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"])('mouseenter'),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], MenuDropDownDirective.prototype, "onMouseEnter", null);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"])('mouseleave'),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], MenuDropDownDirective.prototype, "onMouseLeave", null);
    MenuDropDownDirective = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"])({
            selector: '[menu-dropDown]'
        }),
        __metadata("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["Renderer2"]])
    ], MenuDropDownDirective);
    return MenuDropDownDirective;
}());



/***/ }),

/***/ "./src/app/common/product-profile/productProfile.component.html":
/*!**********************************************************************!*\
  !*** ./src/app/common/product-profile/productProfile.component.html ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"wrap\">\r\n  <img src={{imageUrl}}>\r\n  <h2>{{content}}</h2>\r\n  <div class=\"cover\" menu-dropDown></div>\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/common/product-profile/productProfile.component.less":
/*!**********************************************************************!*\
  !*** ./src/app/common/product-profile/productProfile.component.less ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".wrap {\n  position: relative;\n  display: inline-block;\n  width: 20%;\n  height: 300px;\n  border: 1px solid #e5e5e5;\n  margin: -1px 0 0 -1px;\n  padding: 15px;\n}\n.wrap .cover {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  opacity: 0 ;\n  background: rgba(0, 0, 0);\n}\n.wrap .open {\n  opacity: 0.5 !important;\n  cursor: pointer;\n}\n.wrap img {\n  display: inline-block;\n  width: 100%;\n  height: auto;\n}\n.wrap h2 {\n  font-size: 15px;\n  color: #323423;\n  margin-top: 10px ;\n  height: 48px;\n  overflow: hidden;\n  line-height: 24px;\n  text-align: center;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tbW9uL3Byb2R1Y3QtcHJvZmlsZS9FOi93cC9jb2RlL0Jpb2xvZ3kvc3JjL2FwcC9jb21tb24vcHJvZHVjdC1wcm9maWxlL3Byb2R1Y3RQcm9maWxlLmNvbXBvbmVudC5sZXNzIiwic3JjL2FwcC9jb21tb24vcHJvZHVjdC1wcm9maWxlL3Byb2R1Y3RQcm9maWxlLmNvbXBvbmVudC5sZXNzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsbUJBQUE7RUFDQSxzQkFBQTtFQUNBLFdBQUE7RUFDQSxjQUFBO0VBQ0EsMEJBQUE7RUFDQSxzQkFBQTtFQUNBLGNBQUE7Q0NDRDtBRFJEO0VBVUksbUJBQUE7RUFDQSxPQUFBO0VBQ0EsUUFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EsWUFBQTtFQUNBLDBCQUFBO0NDQ0g7QURqQkQ7RUFvQkksd0JBQUE7RUFDQSxnQkFBQTtDQ0FIO0FEckJEO0VBOEJJLHNCQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7Q0NOSDtBRDFCRDtFQW9DSSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGFBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7Q0NQSCIsImZpbGUiOiJzcmMvYXBwL2NvbW1vbi9wcm9kdWN0LXByb2ZpbGUvcHJvZHVjdFByb2ZpbGUuY29tcG9uZW50Lmxlc3MiLCJzb3VyY2VzQ29udGVudCI6WyIud3JhcCB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB3aWR0aDogMjAlO1xuICBoZWlnaHQ6IDMwMHB4O1xuICBib3JkZXI6IDFweCBzb2xpZCAjZTVlNWU1O1xuICBtYXJnaW46IC0xcHggMCAwIC0xcHg7XG4gIHBhZGRpbmc6IDE1cHg7XG5cbiAgLmNvdmVyIHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgdG9wOjA7XG4gICAgbGVmdDogMDtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgb3BhY2l0eTogMCA7XG4gICAgYmFja2dyb3VuZDogcmdiYSgwLDAsMCk7XG4gIH1cblxuICAub3BlbiB7XG4gICAgb3BhY2l0eTogMC41ICFpbXBvcnRhbnQ7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG5cbiAgLy8mOmhvdmVyIHtcbiAgLy8gIGJhY2tncm91bmQ6IHJnYmEoMCwwLDAsMC41KTtcbiAgLy8gIGN1cnNvcjogcG9pbnRlcjtcbiAgLy99XG5cbiAgaW1nIHtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiBhdXRvO1xuICB9XG5cbiAgaDIge1xuICAgIGZvbnQtc2l6ZTogMTVweDtcbiAgICBjb2xvcjogIzMyMzQyMztcbiAgICBtYXJnaW4tdG9wOiAxMHB4IDtcbiAgICBoZWlnaHQ6IDQ4cHg7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICBsaW5lLWhlaWdodDogMjRweDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIH1cbn1cbiIsIi53cmFwIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHdpZHRoOiAyMCU7XG4gIGhlaWdodDogMzAwcHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNlNWU1ZTU7XG4gIG1hcmdpbjogLTFweCAwIDAgLTFweDtcbiAgcGFkZGluZzogMTVweDtcbn1cbi53cmFwIC5jb3ZlciB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiAwO1xuICBsZWZ0OiAwO1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICBvcGFjaXR5OiAwIDtcbiAgYmFja2dyb3VuZDogcmdiYSgwLCAwLCAwKTtcbn1cbi53cmFwIC5vcGVuIHtcbiAgb3BhY2l0eTogMC41ICFpbXBvcnRhbnQ7XG4gIGN1cnNvcjogcG9pbnRlcjtcbn1cbi53cmFwIGltZyB7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogYXV0bztcbn1cbi53cmFwIGgyIHtcbiAgZm9udC1zaXplOiAxNXB4O1xuICBjb2xvcjogIzMyMzQyMztcbiAgbWFyZ2luLXRvcDogMTBweCA7XG4gIGhlaWdodDogNDhweDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgbGluZS1oZWlnaHQ6IDI0cHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbiJdfQ== */"

/***/ }),

/***/ "./src/app/common/product-profile/productProfile.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/common/product-profile/productProfile.component.ts ***!
  \********************************************************************/
/*! exports provided: ProductProfileComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductProfileComponent", function() { return ProductProfileComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var ProductProfileComponent = /** @class */ (function () {
    function ProductProfileComponent() {
        this.imageUrl = '';
        this.content = '';
    }
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", String)
    ], ProductProfileComponent.prototype, "imageUrl", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", String)
    ], ProductProfileComponent.prototype, "content", void 0);
    ProductProfileComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'product-profile',
            template: __webpack_require__(/*! ./productProfile.component.html */ "./src/app/common/product-profile/productProfile.component.html"),
            styles: [__webpack_require__(/*! ./productProfile.component.less */ "./src/app/common/product-profile/productProfile.component.less")]
        })
    ], ProductProfileComponent);
    return ProductProfileComponent;
}());



/***/ }),

/***/ "./src/app/footer/footer.component.html":
/*!**********************************************!*\
  !*** ./src/app/footer/footer.component.html ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<footer>\r\n  <div class=\"footer-wrap\">\r\n    <dl>\r\n      <dt><span title=\"产品中心\">产品中心</span></dt>\r\n      <dd><span title=\"实验仪器\">实验仪器</span></dd>\r\n      <dd><span title=\"通用耗材\">通用耗材</span></dd>\r\n    </dl>\r\n    <dl>\r\n      <dt><span title=\"关于我们\">关于我们</span></dt>\r\n      <dd><span title=\"联系我们\">联系我们</span></dd>\r\n      <dd><span title=\"公司简介\">公司简介</span></dd>\r\n      <dd><span title=\"企业文化\">企业文化</span></dd>\r\n      <dd><span title=\"新闻资讯\">新闻资讯</span></dd>\r\n    </dl>\r\n    <dl>\r\n      <dt><span title=\"售后服务\">售后服务</span></dt>\r\n      <dd><span title=\"服务条款\">服务条款</span></dd>\r\n      <dd><span title=\"隐私政策\">隐私政策</span></dd>\r\n      <dd><span title=\"订单查询\">订单查询</span></dd>\r\n      <dd><span title=\"联系客服\">联系客服</span></dd>\r\n    </dl>\r\n    <dl>\r\n      <dt><span title=\"服务支持\">服务支持</span></dt>\r\n      <dd><span title=\"技术支持\">技术支持</span></dd>\r\n      <dd><span title=\"下载中心\">下载中心</span></dd>\r\n      <dd><span title=\"客户留言\">客户留言</span></dd>\r\n    </dl>\r\n    <div class=\"weixin\">\r\n      <p>官方微信</p>\r\n      <img src=\"assets/images/weixin.jpg\">\r\n    </div>\r\n  </div>\r\n  <div class=\"copy-right\">\r\n    <p>Copyright © 2007-2019网易公司版权所有 京ICP备17022874号-2</p>\r\n  </div>\r\n</footer>\r\n"

/***/ }),

/***/ "./src/app/footer/footer.component.less":
/*!**********************************************!*\
  !*** ./src/app/footer/footer.component.less ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "footer {\n  border-top: solid 5px #0d75bf;\n  padding: 20px 0;\n  color: #333;\n  font-size: 14px;\n}\nfooter .footer-wrap {\n  width: 1100px;\n  margin: 0 auto;\n}\nfooter .footer-wrap dl {\n  float: left;\n  width: 220px;\n}\nfooter .footer-wrap .weixin {\n  float: left;\n  width: 100px;\n  text-align: center;\n}\nfooter .footer-wrap .weixin img {\n  display: block;\n  width: 100px;\n  height: 100px;\n}\nfooter .footer-wrap dt span:hover,\nfooter .footer-wrap dd span:hover {\n  cursor: pointer;\n  color: #40a8f2;\n}\nfooter .footer-wrap dt {\n  font-size: 18px;\n  font-weight: 400;\n  padding-bottom: 20px;\n}\nfooter .footer-wrap dd {\n  line-height: 30px;\n}\nfooter .footer-wrap::after {\n  content: '';\n  clear: both;\n  display: block;\n}\nfooter .copy-right {\n  background: #333;\n  color: #c2c2c2;\n  line-height: 30px;\n  text-align: center;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZm9vdGVyL0U6L3dwL2NvZGUvQmlvbG9neS9zcmMvYXBwL2Zvb3Rlci9mb290ZXIuY29tcG9uZW50Lmxlc3MiLCJzcmMvYXBwL2Zvb3Rlci9mb290ZXIuY29tcG9uZW50Lmxlc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUE7RUFDRSw4QkFBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0NDREQ7QURIRDtFQU1JLGNBQUE7RUFDQSxlQUFBO0NDQUg7QURQRDtFQVNNLFlBQUE7RUFDQSxhQUFBO0NDQ0w7QURYRDtFQWFNLFlBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7Q0NDTDtBRGhCRDtFQWlCUSxlQUFBO0VBQ0EsYUFBQTtFQUNBLGNBQUE7Q0NFUDtBRHJCRDs7RUF3QlEsZ0JBQUE7RUFDQSxlQUFBO0NDQ1A7QUQxQkQ7RUE2Qk0sZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLHFCQUFBO0NDQUw7QUQvQkQ7RUFrQ00sa0JBQUE7Q0NBTDtBREVHO0VBQ0UsWUFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0NDQUw7QUR2Q0Q7RUEyQ0ksaUJBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtDQ0RIIiwiZmlsZSI6InNyYy9hcHAvZm9vdGVyL2Zvb3Rlci5jb21wb25lbnQubGVzcyIsInNvdXJjZXNDb250ZW50IjpbIkBpbXBvcnQgXCIuLi8uLi9hc3NldHMvY3NzL2NvbmZpZ1wiO1xuXG5mb290ZXIge1xuICBib3JkZXItdG9wOnNvbGlkIDVweCBAYWN0aXZlLWJsdWU7XG4gIHBhZGRpbmc6IDIwcHggMDtcbiAgY29sb3I6IzMzMztcbiAgZm9udC1zaXplOiAxNHB4O1xuICAuZm9vdGVyLXdyYXAge1xuICAgIHdpZHRoOiAxMTAwcHg7XG4gICAgbWFyZ2luOiAwIGF1dG87XG4gICAgZGwge1xuICAgICAgZmxvYXQ6IGxlZnQ7XG4gICAgICB3aWR0aDogMjIwcHg7XG4gICAgfVxuICAgIC53ZWl4aW4ge1xuICAgICAgZmxvYXQ6IGxlZnQ7XG4gICAgICB3aWR0aDogMTAwcHg7XG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICBpbWcge1xuICAgICAgICBkaXNwbGF5OiBibG9jaztcbiAgICAgICAgd2lkdGg6IDEwMHB4O1xuICAgICAgICBoZWlnaHQ6IDEwMHB4O1xuICAgICAgfVxuICAgIH1cbiAgICBkdCxkZCB7XG4gICAgICBzcGFuOmhvdmVyIHtcbiAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xuICAgICAgICBjb2xvcjogQGhvdmVyLWJsdWU7XG4gICAgICB9XG4gICAgfVxuICAgIGR0IHtcbiAgICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICAgIGZvbnQtd2VpZ2h0OiA0MDA7XG4gICAgICBwYWRkaW5nLWJvdHRvbTogMjBweDtcbiAgICB9XG4gICAgZGQge1xuICAgICAgbGluZS1oZWlnaHQ6IDMwcHg7XG4gICAgfVxuICAgICY6OmFmdGVyIHtcbiAgICAgIGNvbnRlbnQ6ICcnO1xuICAgICAgY2xlYXI6IGJvdGg7XG4gICAgICBkaXNwbGF5OiBibG9jaztcbiAgICB9XG4gIH1cbiAgLmNvcHktcmlnaHQge1xuICAgIGJhY2tncm91bmQ6ICMzMzM7XG4gICAgY29sb3I6I2MyYzJjMjtcbiAgICBsaW5lLWhlaWdodDogMzBweDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIH1cbn1cbiIsImZvb3RlciB7XG4gIGJvcmRlci10b3A6IHNvbGlkIDVweCAjMGQ3NWJmO1xuICBwYWRkaW5nOiAyMHB4IDA7XG4gIGNvbG9yOiAjMzMzO1xuICBmb250LXNpemU6IDE0cHg7XG59XG5mb290ZXIgLmZvb3Rlci13cmFwIHtcbiAgd2lkdGg6IDExMDBweDtcbiAgbWFyZ2luOiAwIGF1dG87XG59XG5mb290ZXIgLmZvb3Rlci13cmFwIGRsIHtcbiAgZmxvYXQ6IGxlZnQ7XG4gIHdpZHRoOiAyMjBweDtcbn1cbmZvb3RlciAuZm9vdGVyLXdyYXAgLndlaXhpbiB7XG4gIGZsb2F0OiBsZWZ0O1xuICB3aWR0aDogMTAwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbmZvb3RlciAuZm9vdGVyLXdyYXAgLndlaXhpbiBpbWcge1xuICBkaXNwbGF5OiBibG9jaztcbiAgd2lkdGg6IDEwMHB4O1xuICBoZWlnaHQ6IDEwMHB4O1xufVxuZm9vdGVyIC5mb290ZXItd3JhcCBkdCBzcGFuOmhvdmVyLFxuZm9vdGVyIC5mb290ZXItd3JhcCBkZCBzcGFuOmhvdmVyIHtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBjb2xvcjogIzQwYThmMjtcbn1cbmZvb3RlciAuZm9vdGVyLXdyYXAgZHQge1xuICBmb250LXNpemU6IDE4cHg7XG4gIGZvbnQtd2VpZ2h0OiA0MDA7XG4gIHBhZGRpbmctYm90dG9tOiAyMHB4O1xufVxuZm9vdGVyIC5mb290ZXItd3JhcCBkZCB7XG4gIGxpbmUtaGVpZ2h0OiAzMHB4O1xufVxuZm9vdGVyIC5mb290ZXItd3JhcDo6YWZ0ZXIge1xuICBjb250ZW50OiAnJztcbiAgY2xlYXI6IGJvdGg7XG4gIGRpc3BsYXk6IGJsb2NrO1xufVxuZm9vdGVyIC5jb3B5LXJpZ2h0IHtcbiAgYmFja2dyb3VuZDogIzMzMztcbiAgY29sb3I6ICNjMmMyYzI7XG4gIGxpbmUtaGVpZ2h0OiAzMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG4iXX0= */"

/***/ }),

/***/ "./src/app/footer/footer.component.ts":
/*!********************************************!*\
  !*** ./src/app/footer/footer.component.ts ***!
  \********************************************/
/*! exports provided: FooterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FooterComponent", function() { return FooterComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var FooterComponent = /** @class */ (function () {
    function FooterComponent() {
    }
    FooterComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-footer',
            template: __webpack_require__(/*! ./footer.component.html */ "./src/app/footer/footer.component.html"),
            styles: [__webpack_require__(/*! ./footer.component.less */ "./src/app/footer/footer.component.less")]
        }),
        __metadata("design:paramtypes", [])
    ], FooterComponent);
    return FooterComponent;
}());



/***/ }),

/***/ "./src/app/header/header.component.html":
/*!**********************************************!*\
  !*** ./src/app/header/header.component.html ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<header>\r\n  <div class=\"header-wrap\">\r\n    <img src=\"assets/images/kaola.png\">\r\n    <nav>\r\n      <ul>\r\n        <li routerLink=\"/home\" routerLinkActive=\"active\">\r\n          <span>首页</span>\r\n        </li>\r\n        <li>\r\n          <span>产品中心</span>\r\n        </li>\r\n        <li>\r\n          <span>服务支持</span>\r\n        </li>\r\n        <li menu-dropDown>\r\n          <span>产品应用</span>\r\n          <ul>\r\n            <li>应用案例</li>\r\n            <li>视频中心</li>\r\n          </ul>\r\n        </li>\r\n        <li>\r\n          <span>新闻资讯</span>\r\n        </li>\r\n        <li>\r\n          <span>关于我们</span>\r\n        </li>\r\n        <li>\r\n          <span>联系我们</span>\r\n        </li>\r\n      </ul>\r\n    </nav>\r\n  </div>\r\n</header>\r\n"

/***/ }),

/***/ "./src/app/header/header.component.less":
/*!**********************************************!*\
  !*** ./src/app/header/header.component.less ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "header {\n  font-size: 18px;\n  border-bottom: solid 5px #0d75bf;\n}\nheader .header-wrap {\n  position: relative;\n  width: 1200px;\n  margin: 0 auto;\n  color: #333;\n}\nheader .header-wrap img {\n  display: block;\n  width: 250px;\n  height: 80px;\n}\nheader .header-wrap nav {\n  height: 40px;\n  position: absolute;\n  top: 50%;\n  left: 400px;\n  margin-top: -20px;\n}\nheader .header-wrap nav ul {\n  list-style: none;\n}\nheader .header-wrap nav ul li {\n  position: relative;\n  float: left;\n  padding: 0 15px;\n  height: 40px;\n  line-height: 40px;\n}\nheader .header-wrap nav ul li span:hover {\n  cursor: pointer;\n  color: #40a8f2;\n}\nheader .header-wrap nav ul li ul {\n  position: absolute;\n  visibility: hidden;\n  top: 40px;\n  left: 10px;\n  z-index: 2;\n  font-size: 12px;\n  list-style: none;\n  width: 80px;\n  background: #ffffff;\n  border-radius: 3px;\n  box-shadow: 2px 2px 2px 2px rgba(0, 0, 0, 0.2);\n}\nheader .header-wrap nav ul li ul li {\n  height: 30px;\n  line-height: 30px;\n}\nheader .header-wrap nav ul li ul li:hover {\n  cursor: pointer;\n  color: #40a8f2;\n}\n.active {\n  color: #0d75bf;\n}\n.open ul {\n  visibility: visible !important;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaGVhZGVyL0U6L3dwL2NvZGUvQmlvbG9neS9zcmMvYXBwL2hlYWRlci9oZWFkZXIuY29tcG9uZW50Lmxlc3MiLCJzcmMvYXBwL2hlYWRlci9oZWFkZXIuY29tcG9uZW50Lmxlc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDRSxnQkFBQTtFQUNBLGlDQUFBO0NDQUQ7QURGRDtFQUlJLG1CQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0NDQ0g7QURSRDtFQVNNLGVBQUE7RUFDQSxhQUFBO0VBQ0EsYUFBQTtDQ0VMO0FEYkQ7RUFjTSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxTQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0NDRUw7QURwQkQ7RUFvQlEsaUJBQUE7Q0NHUDtBRHZCRDtFQXNCVSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtDQ0lUO0FEOUJEO0VBNEJZLGdCQUFBO0VBQ0EsZUFBQTtDQ0tYO0FEbENEO0VBZ0NZLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLG9CQUFBO0VBQ0EsbUJBQUE7RUFDQSwrQ0FBQTtDQ0tYO0FEL0NEO0VBNENjLGFBQUE7RUFDQSxrQkFBQTtDQ01iO0FETGE7RUFDRSxnQkFBQTtFQUNBLGVBQUE7Q0NPZjtBREdEO0VBQ0UsZUFBQTtDQ0REO0FESUQ7RUFFSSwrQkFBQTtDQ0hIIiwiZmlsZSI6InNyYy9hcHAvaGVhZGVyL2hlYWRlci5jb21wb25lbnQubGVzcyIsInNvdXJjZXNDb250ZW50IjpbIkBpbXBvcnQgXCIuLi8uLi9hc3NldHMvY3NzL2NvbmZpZ1wiO1xuaGVhZGVyIHtcbiAgZm9udC1zaXplOiAxOHB4O1xuICBib3JkZXItYm90dG9tOnNvbGlkIDVweCBAYWN0aXZlLWJsdWU7XG4gIC5oZWFkZXItd3JhcCB7XG4gICAgcG9zaXRpb246cmVsYXRpdmU7XG4gICAgd2lkdGg6IDEyMDBweDtcbiAgICBtYXJnaW46IDAgYXV0bztcbiAgICBjb2xvcjogIzMzMztcbiAgICBpbWcge1xuICAgICAgZGlzcGxheTogYmxvY2s7XG4gICAgICB3aWR0aDogMjUwcHg7XG4gICAgICBoZWlnaHQ6IDgwcHg7XG4gICAgfVxuICAgIG5hdiB7XG4gICAgICBoZWlnaHQ6IDQwcHg7XG4gICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICB0b3A6IDUwJTtcbiAgICAgIGxlZnQ6IDQwMHB4O1xuICAgICAgbWFyZ2luLXRvcDogLTIwcHg7XG4gICAgICB1bCB7XG4gICAgICAgIGxpc3Qtc3R5bGU6IG5vbmU7XG4gICAgICAgIGxpIHtcbiAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgICAgZmxvYXQ6IGxlZnQ7XG4gICAgICAgICAgcGFkZGluZzogMCAxNXB4O1xuICAgICAgICAgIGhlaWdodDogNDBweDtcbiAgICAgICAgICBsaW5lLWhlaWdodDogNDBweDtcbiAgICAgICAgICBzcGFuOmhvdmVyIHtcbiAgICAgICAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICAgICAgICAgIGNvbG9yOiBAaG92ZXItYmx1ZTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdWwge1xuICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgdmlzaWJpbGl0eTogaGlkZGVuO1xuICAgICAgICAgICAgdG9wOjQwcHg7XG4gICAgICAgICAgICBsZWZ0OjEwcHg7XG4gICAgICAgICAgICB6LWluZGV4OiAyO1xuICAgICAgICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgICAgICAgICAgbGlzdC1zdHlsZTogbm9uZTtcbiAgICAgICAgICAgIHdpZHRoOiA4MHB4O1xuICAgICAgICAgICAgYmFja2dyb3VuZDogQGRlZmF1bHQtd2hpdGU7XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiAzcHg7XG4gICAgICAgICAgICBib3gtc2hhZG93OiAycHggMnB4IDJweCAycHggcmdiYSgwLDAsMCwuMik7XG4gICAgICAgICAgICBsaSB7XG4gICAgICAgICAgICAgIGhlaWdodDogMzBweDtcbiAgICAgICAgICAgICAgbGluZS1oZWlnaHQ6IDMwcHg7XG4gICAgICAgICAgICAgICY6aG92ZXIge1xuICAgICAgICAgICAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICAgICAgICAgICAgICBjb2xvcjogQGhvdmVyLWJsdWU7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cblxuLmFjdGl2ZSB7XG4gIGNvbG9yOiBAYWN0aXZlLWJsdWU7XG59XG5cbi5vcGVuIHtcbiAgdWwge1xuICAgIHZpc2liaWxpdHk6IHZpc2libGUgIWltcG9ydGFudDtcbiAgfVxufVxuIiwiaGVhZGVyIHtcbiAgZm9udC1zaXplOiAxOHB4O1xuICBib3JkZXItYm90dG9tOiBzb2xpZCA1cHggIzBkNzViZjtcbn1cbmhlYWRlciAuaGVhZGVyLXdyYXAge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHdpZHRoOiAxMjAwcHg7XG4gIG1hcmdpbjogMCBhdXRvO1xuICBjb2xvcjogIzMzMztcbn1cbmhlYWRlciAuaGVhZGVyLXdyYXAgaW1nIHtcbiAgZGlzcGxheTogYmxvY2s7XG4gIHdpZHRoOiAyNTBweDtcbiAgaGVpZ2h0OiA4MHB4O1xufVxuaGVhZGVyIC5oZWFkZXItd3JhcCBuYXYge1xuICBoZWlnaHQ6IDQwcHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiA1MCU7XG4gIGxlZnQ6IDQwMHB4O1xuICBtYXJnaW4tdG9wOiAtMjBweDtcbn1cbmhlYWRlciAuaGVhZGVyLXdyYXAgbmF2IHVsIHtcbiAgbGlzdC1zdHlsZTogbm9uZTtcbn1cbmhlYWRlciAuaGVhZGVyLXdyYXAgbmF2IHVsIGxpIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBmbG9hdDogbGVmdDtcbiAgcGFkZGluZzogMCAxNXB4O1xuICBoZWlnaHQ6IDQwcHg7XG4gIGxpbmUtaGVpZ2h0OiA0MHB4O1xufVxuaGVhZGVyIC5oZWFkZXItd3JhcCBuYXYgdWwgbGkgc3Bhbjpob3ZlciB7XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgY29sb3I6ICM0MGE4ZjI7XG59XG5oZWFkZXIgLmhlYWRlci13cmFwIG5hdiB1bCBsaSB1bCB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdmlzaWJpbGl0eTogaGlkZGVuO1xuICB0b3A6IDQwcHg7XG4gIGxlZnQ6IDEwcHg7XG4gIHotaW5kZXg6IDI7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgbGlzdC1zdHlsZTogbm9uZTtcbiAgd2lkdGg6IDgwcHg7XG4gIGJhY2tncm91bmQ6ICNmZmZmZmY7XG4gIGJvcmRlci1yYWRpdXM6IDNweDtcbiAgYm94LXNoYWRvdzogMnB4IDJweCAycHggMnB4IHJnYmEoMCwgMCwgMCwgMC4yKTtcbn1cbmhlYWRlciAuaGVhZGVyLXdyYXAgbmF2IHVsIGxpIHVsIGxpIHtcbiAgaGVpZ2h0OiAzMHB4O1xuICBsaW5lLWhlaWdodDogMzBweDtcbn1cbmhlYWRlciAuaGVhZGVyLXdyYXAgbmF2IHVsIGxpIHVsIGxpOmhvdmVyIHtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBjb2xvcjogIzQwYThmMjtcbn1cbi5hY3RpdmUge1xuICBjb2xvcjogIzBkNzViZjtcbn1cbi5vcGVuIHVsIHtcbiAgdmlzaWJpbGl0eTogdmlzaWJsZSAhaW1wb3J0YW50O1xufVxuIl19 */"

/***/ }),

/***/ "./src/app/header/header.component.ts":
/*!********************************************!*\
  !*** ./src/app/header/header.component.ts ***!
  \********************************************/
/*! exports provided: HeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderComponent", function() { return HeaderComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var HeaderComponent = /** @class */ (function () {
    function HeaderComponent() {
    }
    HeaderComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-header',
            template: __webpack_require__(/*! ./header.component.html */ "./src/app/header/header.component.html"),
            styles: [__webpack_require__(/*! ./header.component.less */ "./src/app/header/header.component.less")]
        }),
        __metadata("design:paramtypes", [])
    ], HeaderComponent);
    return HeaderComponent;
}());



/***/ }),

/***/ "./src/app/home/home.component.html":
/*!******************************************!*\
  !*** ./src/app/home/home.component.html ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div>\r\n  <div class=\"swiper-container\">\r\n    <div class=\"swiper-wrapper\">\r\n      <div class=\"swiper-slide\">\r\n        <img src=\"assets/images/1.jpg\">\r\n      </div>\r\n      <div class=\"swiper-slide\">\r\n        <img src=\"assets/images/2.jpg\">\r\n      </div>\r\n      <div class=\"swiper-slide\">\r\n        <img src=\"assets/images/3.jpg\">\r\n      </div>\r\n    </div>\r\n    <div class=\"swiper-pagination\"></div>\r\n    <div class=\"swiper-button-next\"></div>\r\n    <div class=\"swiper-button-prev\"></div>\r\n  </div>\r\n  <section class=\"product\">\r\n    <h1>产品中心</h1>\r\n    <div class=\"wrap\">\r\n      <ng-container *ngFor=\"let product of productList\">\r\n        <product-profile [content]=\"product.content\" [imageUrl]=\"product.url\"></product-profile>\r\n      </ng-container>\r\n    </div>\r\n  </section>\r\n  <section class=\"news\">\r\n    <h1>新闻中心</h1>\r\n    <div class=\"wrap\">\r\n\r\n    </div>\r\n  </section>\r\n</div>\r\n\r\n"

/***/ }),

/***/ "./src/app/home/home.component.less":
/*!******************************************!*\
  !*** ./src/app/home/home.component.less ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".swiper-container {\n  width: 1200px;\n  height: 600px;\n  margin-left: auto;\n  margin-right: auto;\n}\n.swiper-slide {\n  text-align: center;\n  font-size: 18px;\n  background: #fff;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n.product {\n  width: 1200px;\n  margin: 60px auto 0 auto;\n}\n.product h1 {\n  text-align: center;\n}\n.product .wrap {\n  font-size: 0;\n}\n.news {\n  width: 1200px;\n  margin: 60px auto 0 auto;\n}\n.news h1 {\n  text-align: center;\n}\n.news .wrap {\n  font-size: 0;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9FOi93cC9jb2RlL0Jpb2xvZ3kvc3JjL2FwcC9ob21lL2hvbWUuY29tcG9uZW50Lmxlc3MiLCJzcmMvYXBwL2hvbWUvaG9tZS5jb21wb25lbnQubGVzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGNBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtDQ0NEO0FEQ0Q7RUFDRSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFLQSxjQUFBO0VBSUEsd0JBQUE7RUFJQSxvQkFBQTtDQ0FEO0FER0Q7RUFDRSxjQUFBO0VBQ0EseUJBQUE7Q0NERDtBREREO0VBSUksbUJBQUE7Q0NBSDtBREpEO0VBT0ksYUFBQTtDQ0FIO0FESUQ7RUFDRSxjQUFBO0VBQ0EseUJBQUE7Q0NGRDtBREFEO0VBSUksbUJBQUE7Q0NESDtBREhEO0VBT0ksYUFBQTtDQ0RIIiwiZmlsZSI6InNyYy9hcHAvaG9tZS9ob21lLmNvbXBvbmVudC5sZXNzIiwic291cmNlc0NvbnRlbnQiOlsiLnN3aXBlci1jb250YWluZXIge1xuICB3aWR0aDogMTIwMHB4O1xuICBoZWlnaHQ6IDYwMHB4O1xuICBtYXJnaW4tbGVmdDogYXV0bztcbiAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xufVxuLnN3aXBlci1zbGlkZSB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZm9udC1zaXplOiAxOHB4O1xuICBiYWNrZ3JvdW5kOiAjZmZmO1xuXG4gIGRpc3BsYXk6IC13ZWJraXQtYm94O1xuICBkaXNwbGF5OiAtbXMtZmxleGJveDtcbiAgZGlzcGxheTogLXdlYmtpdC1mbGV4O1xuICBkaXNwbGF5OiBmbGV4O1xuICAtd2Via2l0LWJveC1wYWNrOiBjZW50ZXI7XG4gIC1tcy1mbGV4LXBhY2s6IGNlbnRlcjtcbiAgLXdlYmtpdC1qdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIC13ZWJraXQtYm94LWFsaWduOiBjZW50ZXI7XG4gIC1tcy1mbGV4LWFsaWduOiBjZW50ZXI7XG4gIC13ZWJraXQtYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cblxuLnByb2R1Y3Qge1xuICB3aWR0aDogMTIwMHB4O1xuICBtYXJnaW46IDYwcHggYXV0byAwIGF1dG87XG4gIGgxIHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIH1cbiAgLndyYXAge1xuICAgIGZvbnQtc2l6ZTogMDtcbiAgfVxufVxuXG4ubmV3cyB7XG4gIHdpZHRoOiAxMjAwcHg7XG4gIG1hcmdpbjogNjBweCBhdXRvIDAgYXV0bztcbiAgaDEge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgfVxuICAud3JhcCB7XG4gICAgZm9udC1zaXplOiAwO1xuICB9XG59XG4iLCIuc3dpcGVyLWNvbnRhaW5lciB7XG4gIHdpZHRoOiAxMjAwcHg7XG4gIGhlaWdodDogNjAwcHg7XG4gIG1hcmdpbi1sZWZ0OiBhdXRvO1xuICBtYXJnaW4tcmlnaHQ6IGF1dG87XG59XG4uc3dpcGVyLXNsaWRlIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBmb250LXNpemU6IDE4cHg7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIGRpc3BsYXk6IC13ZWJraXQtYm94O1xuICBkaXNwbGF5OiAtbXMtZmxleGJveDtcbiAgZGlzcGxheTogLXdlYmtpdC1mbGV4O1xuICBkaXNwbGF5OiBmbGV4O1xuICAtd2Via2l0LWJveC1wYWNrOiBjZW50ZXI7XG4gIC1tcy1mbGV4LXBhY2s6IGNlbnRlcjtcbiAgLXdlYmtpdC1qdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIC13ZWJraXQtYm94LWFsaWduOiBjZW50ZXI7XG4gIC1tcy1mbGV4LWFsaWduOiBjZW50ZXI7XG4gIC13ZWJraXQtYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cbi5wcm9kdWN0IHtcbiAgd2lkdGg6IDEyMDBweDtcbiAgbWFyZ2luOiA2MHB4IGF1dG8gMCBhdXRvO1xufVxuLnByb2R1Y3QgaDEge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG4ucHJvZHVjdCAud3JhcCB7XG4gIGZvbnQtc2l6ZTogMDtcbn1cbi5uZXdzIHtcbiAgd2lkdGg6IDEyMDBweDtcbiAgbWFyZ2luOiA2MHB4IGF1dG8gMCBhdXRvO1xufVxuLm5ld3MgaDEge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG4ubmV3cyAud3JhcCB7XG4gIGZvbnQtc2l6ZTogMDtcbn1cbiJdfQ== */"

/***/ }),

/***/ "./src/app/home/home.component.ts":
/*!****************************************!*\
  !*** ./src/app/home/home.component.ts ***!
  \****************************************/
/*! exports provided: HomeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeComponent", function() { return HomeComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var HomeComponent = /** @class */ (function () {
    function HomeComponent() {
        this.productList = [
            { url: 'assets/images/4.jpg',
                content: 'Acura® manual手动移液器' },
            { url: 'assets/images/5.jpg',
                content: 'Acura® electro电动移液器' },
            { url: 'assets/images/6.jpg',
                content: 'Acurex™紧凑型瓶口配液器' },
            { url: 'assets/images/7.jpg',
                content: 'Calibrex™瓶口分液器' },
            { url: 'assets/images/8.jpg',
                content: 'Dosys™连续分液注射器' },
            { url: 'assets/images/9.jpg',
                content: ' Profiller™移液管控制器' },
            { url: 'assets/images/10.jpg',
                content: 'Acura®self-refill连续分液器' },
            { url: 'assets/images/11.jpg',
                content: 'Stepper™ 连续注射移液器' },
            { url: 'assets/images/12.jpg',
                content: 'Qualitix®移液器耗材' },
            { url: 'assets/images/13.jpg',
                content: '生物培养消耗品' }
        ];
    }
    HomeComponent.prototype.ngOnInit = function () {
        var swiper = new Swiper('.swiper-container', {
            slidesPerView: 1,
            spaceBetween: 30,
            loop: true,
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
        });
    };
    HomeComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-home',
            template: __webpack_require__(/*! ./home.component.html */ "./src/app/home/home.component.html"),
            styles: [__webpack_require__(/*! ./home.component.less */ "./src/app/home/home.component.less")]
        }),
        __metadata("design:paramtypes", [])
    ], HomeComponent);
    return HomeComponent;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.error(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! E:\wp\code\Biology\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map